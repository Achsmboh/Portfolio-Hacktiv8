# FINAL PROJECT HACKTIV8 - KARTU PRAKERJA

##

Kode Peserta : INPG-PKJ03-015
Nama Pseserta : Achmad Maulana Achsan

## About Project

Project ini merupakan final project dari Kartu Prakerja bersama Hacktiv8 dengan pelatihan Belajar Langkah Fundamental Untuk Menjadi Web Programming

## Live Demo

Here is a working live demo : https://final-project-prakerja.netlify.app/

## Sumberdaya

- HTML
- CSS
- JavaScript
